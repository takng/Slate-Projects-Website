
$(document).ready(function(){
	
	$('.subscribe-email').removeAttr('placeholder');	
	$('.subscribe-email').val('Enter your email...');
	
});